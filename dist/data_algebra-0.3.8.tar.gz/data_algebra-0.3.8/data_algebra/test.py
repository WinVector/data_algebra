from data_algebra.data_ops import *
import pandas

d = pandas.DataFrame({
    'x': [1, 2, 3],
    'y': [3, 4, 4],
})

td = describe_table(d)

a = td.extend(
    { 'z': 'x.mean()' },
    partition_by=['y']
)

from data_algebra.arrow import *

a1 = DataOpArrow(a)

a2 = DataOpArrow(a1.cod_as_table().extend({
    'ratio': 'y / x'
}))

a1.cod_as_table() == a2.dom_as_table()
a1.cod() == a2.dom()