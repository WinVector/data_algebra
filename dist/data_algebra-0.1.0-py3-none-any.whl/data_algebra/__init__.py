# have user override this with:
# import data_algebra
# data_algebra._ref_to_global_namespace = globals()
_ref_to_global_namespace = None
